from dataclasses import dataclass

@dataclass
class Elemento:
    palavra: str
    quantidade: int