from __future__ import annotations
from copy import deepcopy

from Elemento import Elemento


class TabelaHash:
    def __init__(self, tamanho: int) -> None:
        self.tabela: list[list] = [[]] * tamanho
        self.tamanhoMaximo = tamanho

    def insere(self, palavra: str) -> None:
        if palavra == "" and palavra != " ":
            return None
        
        indiceAhInserir = self._hash(palavra.lower())
        print(f"palarvar: {palavra} - indice: {indiceAhInserir}")

        palavraDentroDaLista = self.buscaNaLista(self.tabela[indiceAhInserir], palavra.lower())
        if  palavraDentroDaLista is not None and palavraDentroDaLista.palavra == palavra:
            palavraDentroDaLista.quantidade += 1
            return None
        
        elif palavraDentroDaLista is not None:
            palavraDentroDaLista.append(Elemento(palavra=palavra, quantidade=1))
            return
  
        lista = []
        lista.append(Elemento(palavra=palavra, quantidade=1))
        self.tabela[indiceAhInserir] = lista

    def buscaNaLista(self, lista: list[Elemento], palavra: str) -> Elemento:
        for elemento in lista:
            if elemento.palavra == palavra:
                return elemento
            
        return None

    def _mapeia(self, chave: str) -> int:
        chave = chave.upper()

        soma = 0
        for letra in chave:
            soma += ord(letra)

        return soma % self.tamanhoMaximo
    
    def _hash(self, chave: str) -> int:
        soma = 0
        indice = 0

        comprimento = len(chave)
        temComprimentoImpar = comprimento % 2 == 1
        if temComprimentoImpar:
            chave = chave + ' '
        
        while (indice < comprimento):
            soma += self.tamanhoMaximo*ord(chave[indice]) + ord(chave[indice + 1])
            soma = soma % 19937
            indice += 2

        return soma % self.tamanhoMaximo
