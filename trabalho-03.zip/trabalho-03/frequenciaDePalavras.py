from __future__ import annotations
from enum import Enum

from TabelaHash import TabelaHash
from Elemento import Elemento

class Opcao(Enum):
    ARMAZENAR: int = 1
    CONSULTAR: int = 2
    RELATORIO: int = 3
    SAIR: int = 4

class ContadorDePalavras:
    def __init__(self):
        self.tabelaHash = TabelaHash(10)

    def escolherOpcao(self) -> int:
        print("="*50)
        print("Opções:\n")
        print("1 - ARMAZENAR")
        print("2 - CONSULTAR")
        print("3 - RELATORIO")
        print("4 - SAIR")
        print("="*50, end="\n")
        
        opcao = int(input("\nDigite a opção desejada: "))
        print("\n")

        return opcao
    
    def armazenar(self, palavras: list[str]) -> None:
        for palavra in palavras:
            self.tabelaHash.insere(palavra)

def iniciarCadastroDePessoa() -> None:
        opcaoAtual = None
        simulador = ContadorDePalavras()

        while True:
            opcaoAtual = simulador.escolherOpcao()

            if opcaoAtual == Opcao.ARMAZENAR.value:
                texto = input("Digite o texto: ").lower()
                
                palavras = texto.lower().split(" ")
                simulador.armazenar(palavras)

                print(simulador.tabelaHash.tabela)

            elif opcaoAtual == Opcao.BUSCA.value:
                simulador.encontrarPessoa()

            elif opcaoAtual == Opcao.RELATORIO.value:
                simulador.exibeRelatorio()

            elif opcaoAtual == Opcao.SAIR.value:
                print("Saindo...")
                break

            else:
                print("Opção inválida, tente novamente.\n")
                iniciarCadastroDePessoa()
            
iniciarCadastroDePessoa()