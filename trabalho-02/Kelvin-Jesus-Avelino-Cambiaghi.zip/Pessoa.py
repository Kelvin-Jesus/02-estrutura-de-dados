from dataclasses import dataclass

@dataclass
class Pessoa:
    nome: str
    idade: int
    sexo: str
    peso: float